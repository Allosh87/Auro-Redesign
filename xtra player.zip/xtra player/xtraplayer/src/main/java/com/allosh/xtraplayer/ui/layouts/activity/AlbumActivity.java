package com.allosh.xtraplayer.ui.layouts.activity;

import android.app.ActivityManager;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.allosh.xtraplayer.R;
import com.allosh.xtraplayer.utils.ListSongs;
import com.allosh.xtraplayer.utils.PermissionChecker;
import com.allosh.xtraplayer.utils.Utils;
import com.allosh.xtraplayer.utils.adapters.AlbumSongListAdapter;

import java.io.File;
import com.allosh.xtraplayer.utils.items.Album;
import android.net.Uri;
import java.util.ArrayList;
import com.facebook.drawee.view.SimpleDraweeView;
import com.allosh.xtraplayer.utils.items.Song;


public class AlbumActivity extends AppCompatActivity {

    private RecyclerView rv;
    //private ImageView albumArt;
    private PermissionChecker permissionChecker;
	private SimpleDraweeView mAlbumArt;
	
	private ArrayList<Song> mSongList;
	

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_album);
        initView();
		
    }

    private void initView() {
		
		mSongList= ListSongs.getAlbumSongList(this,
		getIntent().getLongExtra("albumId", 0));
		
        permissionChecker = new PermissionChecker(this, this, findViewById(R.id.base_view_album));
        rv = (RecyclerView) findViewById(R.id.rv_album_activity);
		mAlbumArt = (SimpleDraweeView) findViewById(R.id.album_activity_img);
      //  albumArt = (ImageView) findViewById(R.id.activity_album_art);
       // int size = new Utils(this).getWindowWidth();
       // int panelSize = (int) getResources().getDimension(R.dimen.album_title_height);
      //  int height = new Utils(this).getWindowHeight() - panelSize * 2;
       // setAlbumArtSize(size, height);
		
        //setAlbumArt(size, new Utils(this).getWindowHeight());
		
		
        CollapsingToolbarLayout collapsingToolbarLayout = (CollapsingToolbarLayout)
                findViewById(R.id.collapsingtoolbarlayout_album);
        if (collapsingToolbarLayout != null)
            collapsingToolbarLayout.setTitle(getIntent().getStringExtra("albumName"));
			
	
		
			
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar_album);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    
		addSongList();
     //   setForAnimation();
		
		setHeaderImage();
		
    }


	
	private void setHeaderImage ( ) {
		
		Uri albumArt = ListSongs.getAlbumArtUri ( mSongList.get ( 0 ).getAlbumId() ) ;

		if ( albumArt != null ) {

			mAlbumArt.setImageURI(  albumArt );

		} else if (albumArt == null) {

			mAlbumArt.setImageResource( R.drawable.default_art);
			
		}
	
	}

	
/*
    private void setAlbumArtSize(int width, int height) {
        LinearLayout.LayoutParams lp = new LinearLayout
                .LayoutParams(width, height);
       mAlbumArt.setLayoutParams(lp);
    }
*/
    private void setForAnimation() {
        rv.scrollTo(0, 100);
    }

    private void addSongList() {
        rv.setLayoutManager(new LinearLayoutManager(this));
        rv.setAdapter(new AlbumSongListAdapter(this, mSongList , this, permissionChecker));
		mSongList= ListSongs.getAlbumSongList(this,
		getIntent().getLongExtra("albumId", 0));
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        permissionChecker.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

	
	
    public void setAlbumArts (int width, int height) {
		
        Uri albumArt = ListSongs.getAlbumArtUri ( mSongList.get ( 0 ).getAlbumId() ) ;

		if ( albumArt != null ) {

			mAlbumArt.setImageURI(  albumArt );

		} else {

			mAlbumArt.setImageResource( R.drawable.default_art);

		}

        int colorPrimary = getIntent().getIntExtra("albumColor", ContextCompat.getColor(this, R.color.colorPrimary));
        
		//findViewById(R.id.album_song_name_holder).setBackgroundColor(colorPrimary);
		
        ((CollapsingToolbarLayout) findViewById(R.id.collapsingtoolbarlayout_album))
                .setContentScrimColor(colorPrimary);
      //  ((CollapsingToolbarLayout) findViewById(R.id.collapsingtoolbarlayout_album))
     //           .setStatusBarScrimColor(getAutoStatColor(colorPrimary));
				/*
        if (Build.VERSION.SDK_INT >= 21) {
            ActivityManager.TaskDescription taskDescription = new
                    ActivityManager.TaskDescription(getIntent().getStringExtra("albumName"),
                    BitmapFactory.decodeResource(getResources(), R.mipmap.ic_launcher), colorPrimary);
					
            setTaskDescription(taskDescription);
			
        }
        */
    }
	

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                super.onBackPressed();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    public int getAutoStatColors (int baseColor) {
        float[] hsv = new float[3];
        Color.colorToHSV(baseColor, hsv);
        hsv[2] *= 1.4f;
        return Color.HSVToColor(hsv);
    }

}
