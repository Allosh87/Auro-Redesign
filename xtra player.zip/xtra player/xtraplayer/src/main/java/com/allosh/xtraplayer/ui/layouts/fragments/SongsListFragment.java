package com.allosh.xtraplayer.ui.layouts.fragments;

import android.Manifest;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import com.allosh.xtraplayer.R;
import com.allosh.xtraplayer.utils.ListSongs;
import com.allosh.xtraplayer.utils.PermissionChecker;
import com.allosh.xtraplayer.utils.adapters.SongListAdapter;
import com.allosh.xtraplayer.utils.decorations.SimpleDividerItemDecoration;
import com.allosh.xtraplayer.utils.items.Song;
import com.simplecityapps.recyclerview_fastscroll.views.FastScrollRecyclerView;
import java.util.ArrayList;
import com.github.florent37.materialviewpager.header.MaterialViewPagerHeaderDecorator;
import android.support.v7.app.AlertDialog;
import android.content.DialogInterface;
import android.support.v4.app.ActivityCompat;
import android.app.Activity;

/**
 * Created by architjn on 27/11/15.
 */
public class SongsListFragment extends Fragment {

	private static final int PERMISSION_READ_EXTERNAL_STORAGE = 0;
	
    private Context context;
    private View mainView;
    private FastScrollRecyclerView rv;
    private SongListAdapter adapter;

    private PermissionChecker permissionChecker;
    private View emptyView;

	public static SongsListFragment newInstance() {
        return new SongsListFragment();
    }

    @Override
    public View onCreateView ( LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState ) {
        View view = inflater.inflate ( R.layout.fragment_songs, container, false );
        context = view.getContext ( );
        mainView = view;
        init ( );
        return view;
    }

    private void init ( ) {
        rv = mainView.findViewById ( R.id.fast_scroll_recyclerView );
        emptyView = mainView.findViewById ( R.id.songs_empty_view );
		loadSongs();
    //    checkPermissions ( );
    }

	
    private void checkPermissions ( ) {
        permissionChecker = new PermissionChecker ( context, getActivity ( ), mainView );
        permissionChecker.check ( Manifest.permission.WRITE_EXTERNAL_STORAGE,
		getResources ( ).getString ( R.string.storage_permission ),
		new PermissionChecker.OnPermissionResponse ( ) {
			@Override
			public void onAccepted ( ) {
				
				loadSongs();
			
			}

			@Override
			public void onDecline ( ) {
			//	getActivity ( ).finish ( );
			//	requestAgain();
			}

			
		} );
    }
	

	
	
	private void loadSongs () {
		
		ArrayList<Song> songList = ListSongs.getSongList( context );
		adapter = new SongListAdapter ( context, this, songList, permissionChecker );
		
		if ( songList.size ( ) < 1 ) {
            listIsEmpty ( );
        } else {
			
			listNoMoreEmpty();
		
		rv.setLayoutManager( new LinearLayoutManager(getActivity()) );
		rv.setHasFixedSize(true);
        rv.addItemDecoration(new MaterialViewPagerHeaderDecorator());
		
        rv.setOnScrollListener ( new RecyclerView.OnScrollListener ( ) {
            @Override
            public void onScrolled ( RecyclerView recyclerView, int dx, int dy ) {
                super.onScrolled ( recyclerView, dx, dy );
                adapter.recyclerScrolled ( );
            }

            @Override
            public void onScrollStateChanged ( RecyclerView recyclerView, int newState ) {
                super.onScrollStateChanged ( recyclerView, newState );

                if ( newState == AbsListView.OnScrollListener.SCROLL_STATE_FLING ) {
                    // Do something
                } else if ( newState == AbsListView.OnScrollListener.SCROLL_STATE_TOUCH_SCROLL ) {
                    // Do something
                } else {
                    // Do something
                }
            }
        } );
		
        
        rv.setAdapter ( adapter );
        }
		
	}

    

    public void listIsEmpty ( ) {
        emptyView.setVisibility ( View.VISIBLE );
        rv.setVisibility ( View.GONE );
    }

    public void listNoMoreEmpty() {
        rv.setVisibility(View.VISIBLE);
        emptyView.setVisibility(View.GONE);
    }

/*
    @Override
    public void onRequestPermissionsResult ( int requestCode, @NonNull String[] permissions,
	@NonNull int[] grantResults ) {
        permissionChecker.onRequestPermissionsResult ( requestCode, permissions, grantResults );
    }
*/
    public void onBackPress ( ) {
        adapter.onBackPressed ( );
    }

    public void setPermissionChecker ( PermissionChecker permissionChecker ) {
        this.permissionChecker = permissionChecker;
    }
}
