package com.allosh.xtraplayer.utils.adapters;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.allosh.xtraplayer.R;
import com.allosh.xtraplayer.ui.layouts.activity.ArtistActivity;
import com.allosh.xtraplayer.ui.layouts.activity.MainActivity;
import com.allosh.xtraplayer.ui.layouts.fragments.ArtistListFragment;
import com.allosh.xtraplayer.utils.handlers.ArtistImgHandler;
import com.allosh.xtraplayer.utils.decorations.ArtistSubListSpacesItemDecoration;
import com.allosh.xtraplayer.utils.ImageConverter;
import com.allosh.xtraplayer.utils.Utils;
import com.allosh.xtraplayer.utils.items.Artist;


import java.io.File;
import java.util.ArrayList;
import com.allosh.xtraplayer.utils.ListSongs;
import android.net.Uri;
import com.facebook.drawee.view.SimpleDraweeView;
import com.allosh.xtraplayer.utils.adapters.ArtistsListAdapter.SimpleItemViewHolder;
import com.simplecityapps.recyclerview_fastscroll.views.FastScrollRecyclerView;

/**
 * Created by architjn on 28/11/15.
 */
public class ArtistsListAdapter extends RecyclerView.Adapter<ArtistsListAdapter.SimpleItemViewHolder> implements FastScrollRecyclerView.SectionedAdapter {

    private ArrayList<Artist> mArtists;
    private ArtistListFragment fragment;
    private Context context;
    private int expandedPosition = -1;
    private SimpleItemViewHolder expandedHolder;
    private int expandSize = 255;
    private ArtistSubListAdapter extendedAdapter;

    public ArtistsListAdapter ( Context context, ArrayList<Artist> items, ArtistListFragment fragment ) {
        this.context = context;
        this.mArtists = items;
        this.fragment = fragment;
    }

    @Override
    public ArtistsListAdapter.SimpleItemViewHolder onCreateViewHolder ( ViewGroup parent,
	int viewType ) {
        View itemView = LayoutInflater.from ( parent.getContext ( ) ).
		inflate ( R.layout.artist_list_item, parent, false );
        return new SimpleItemViewHolder ( itemView );
    }

    @Override
    public void onBindViewHolder ( final ArtistsListAdapter.SimpleItemViewHolder holder, final int position ) {

		Artist artist = mArtists.get ( position );
        Utils utils = new Utils ( context );
        holder.img.setImageBitmap ( utils.getBitmapOfVector ( R.drawable.default_artist_art,
		utils.dpToPx ( 50 ), utils.dpToPx ( 50 ) ) );
        holder.name.setText ( mArtists.get ( position ).getArtistName ( ) );

		setAlbumArt ( holder, position );
        holder.songCount.setText ( context.getResources ( ).getString ( R.string.songs )
		+ " " + mArtists.get ( position ).getNumberOfSongs ( ) + " . "
		+ context.getResources ( ).getString ( R.string.albums ) + " "
		+ mArtists.get ( position ).getNumberOfAlbums ( ) );
		
        if ( position == expandedPosition ) {
            expandWithoutAnimation ( holder );
        } else {
            collapseWithoutAnimation ( holder );
        }
        setOnClicks ( holder, position );
    }

	private void setAlbumArt ( final ArtistsListAdapter.SimpleItemViewHolder holder, int position ) {
		//Artist artist = mArtists.get(position);
		//	Uri albumArt = ListSongs.getAlbumArtUri ( artist.getArtistId () ) ;

		ArtistImgHandler imgHandler = new ArtistImgHandler ( context ) {
            @Override
            public void onDownloadComplete ( final String url ) {
                if ( url != null )
                    ( (Activity) context ).runOnUiThread ( new Runnable ( ) {
                        @Override
                        public void run ( ) {

							holder.img.setImageURI ( url, holder );

                        }
                    } );
            }
        };

		String path = imgHandler.getArtistImgFromDB ( "name" );

        if ( path != null && !path.matches ( "" ) ) {

			holder.img.setImageURI ( path , holder );

        } else {

            String urlIfAny = imgHandler.getArtistArtWork ( mArtists.get ( position ).getArtistName ( ), position );

            if ( urlIfAny != null ) {

			}

			holder.img.setImageResource ( R.drawable.default_artist_art );
        }


	}


    private void setOnClicks ( final SimpleItemViewHolder holder, final int position ) {
        holder.mainView.setOnClickListener ( new View.OnClickListener ( ) {
            @Override
            public void onClick ( View view ) {
                // Check for an expanded view, collapse if you find one

				Intent i = new Intent ( context, ArtistActivity.class );
				i.putExtra ( "name", mArtists.get ( position ).getArtistName ( ) );
				i.putExtra ( "id", mArtists.get ( position ).getArtistId ( ) );
				context.startActivity ( i );

				if ( expandedPosition != position ) {

                    if ( expandedPosition >= 0 ) {
                        collapse ( );
                    }

                } else {

					collapse ( );

				}

            }
        } );

        holder.songsButton.setOnClickListener ( new View.OnClickListener ( ) {
            @Override
            public void onClick ( View view ) {
                Intent i = new Intent ( context, ArtistActivity.class );
                i.putExtra ( "name", mArtists.get ( position ).getArtistName ( ) );
                i.putExtra ( "id", mArtists.get ( position ).getArtistId ( ) );
                context.startActivity ( i );
            }
        } );

        holder.shuffleButton.setOnClickListener ( new View.OnClickListener ( ) {
            @Override
            public void onClick ( View view ) {

            }
        } );

        holder.menu.setOnClickListener ( new View.OnClickListener ( ) {
            @Override
            public void onClick ( View view ) {

				if ( expandedPosition != position ) {

                    if ( expandedPosition >= 0 ) {
                        collapse ( );
                    }
					
                    expand ( holder, position );

                } else {

					collapse ( );

				}

            }
        } );

    }


    private void expand ( SimpleItemViewHolder holder, int position ) {
        expandedPosition = position;
        expandedHolder = holder;
        animateElevation ( 0, 12, holder.mainView );
        holder.mainView.setBackgroundColor ( 0xffffffff );
        if ( expandedPosition == -1 )
            animateHeight ( 0, dpToPx ( expandSize ), holder.expandedArea, false );
        else
            animateHeight ( 0, dpToPx ( expandSize ), holder.expandedArea, true );
        setSubList ( position );
    }

    private void collapse ( ) {
        animateElevation ( 12, 0, expandedHolder.mainView );
        expandedHolder.mainView.setBackgroundColor ( 0xfffafafa );
        animateHeight ( dpToPx ( expandSize ), 0, expandedHolder.expandedArea, false );
        expandedPosition = -1;
        expandedHolder = null;
    }

    private void collapseWithoutAnimation ( SimpleItemViewHolder holder ) {
        holder.mainView.setElevation ( 0 );
        holder.expandedArea.setLayoutParams ( new LinearLayout.LayoutParams (
		ViewGroup.LayoutParams.MATCH_PARENT, dpToPx ( 0 ) ) );
        holder.mainView.setBackgroundColor ( 0xfffafafa );
    }

    private void expandWithoutAnimation ( SimpleItemViewHolder holder ) {
        holder.mainView.setElevation ( 12 );
        holder.expandedArea.setLayoutParams ( new LinearLayout.LayoutParams (
		ViewGroup.LayoutParams.MATCH_PARENT, dpToPx ( expandSize ) ) );
        holder.mainView.setBackgroundColor ( 0xffffffff );
    }

    @Override
    public int getItemCount ( ) {
        return mArtists.size ( );
    }


    public int dpToPx ( int dp ) {
        DisplayMetrics displayMetrics = context.getResources ( ).getDisplayMetrics ( );
        int px = Math.round ( dp * ( displayMetrics.xdpi / DisplayMetrics.DENSITY_DEFAULT ) );
        return px;
    }

    private void animateElevation ( int from, int to, final View view ) {
        Integer elevationFrom = from;
        Integer elevationTo = to;
        ValueAnimator colorAnimation =
		ValueAnimator.ofObject (
		new ArgbEvaluator ( ), elevationFrom, elevationTo );
        colorAnimation.addUpdateListener (
		new ValueAnimator.AnimatorUpdateListener ( ) {
			@Override
			public void onAnimationUpdate ( ValueAnimator animator ) {
				view.setElevation (
				(Integer) animator.getAnimatedValue ( ) );
			}

		} );
        colorAnimation.start ( );
    }

    private void animateHeight ( int from, int to, final View view, boolean delay ) {
        // Declare a ValueAnimator object
        int duration = 300;
        ValueAnimator valueAnimator;
        valueAnimator = ValueAnimator.ofInt ( from, to ); // These values in this method can be changed to expand however much you like
        valueAnimator.setDuration ( duration );
        valueAnimator.setInterpolator ( new DecelerateInterpolator ( ) );
        if ( delay )
            valueAnimator.setStartDelay ( duration );
        valueAnimator.setInterpolator ( new AccelerateDecelerateInterpolator ( ) );
        valueAnimator.addUpdateListener ( new ValueAnimator.AnimatorUpdateListener ( ) {
            public void onAnimationUpdate ( ValueAnimator animation ) {
                Integer value = (Integer) animation.getAnimatedValue ( );
                view.getLayoutParams ( ).height = value.intValue ( );
                view.requestLayout ( );
            }
        } );


        valueAnimator.start ( );
    }

    public void recyclerScrolled () {
		
		
		//	collapse ( );

		
		
		/*
        if (expandedPosition != -1 && expandedHolder != null) {
			
			collapse();
		}
         */
    }

    public void setSubList ( int position ) {
        if ( expandedHolder.rv.getAdapter ( ) == null ) {
            expandedHolder.rv.setLayoutManager ( new LinearLayoutManager ( context,
			LinearLayoutManager.HORIZONTAL, false ) );
            expandedHolder.rv.addItemDecoration (
			new ArtistSubListSpacesItemDecoration ( context, dpToPx ( 5 ) ) );
        }
        extendedAdapter = new ArtistSubListAdapter ( context, mArtists.get ( position ).getArtistId ( ) );
        expandedHolder.rv.setAdapter ( extendedAdapter );
    }


	@Override
	public String getSectionName ( int pos ) {
		try {
			//   return String.valueOf ( mSongs.get ( pos )._title.charAt ( 0 ) );
			return String.valueOf ( mArtists.get ( pos ).getArtistName ( ).charAt ( 0 ) );
        } catch (Exception e) {
            e.printStackTrace ( );
            return "-";
        }
	}



    public void onBackPressed ( ) {
        if ( expandedPosition != -1 )
            collapse ( );
        else
            ( (MainActivity) fragment.getActivity ( ) ).killActivity ( );
    }


    public class SimpleItemViewHolder extends RecyclerView.ViewHolder {

        public TextView name, songCount, songsButton, shuffleButton;
        public View mainView, menu;
        public LinearLayout expandedArea;
        public SimpleDraweeView img;
        public RecyclerView rv;

        public SimpleItemViewHolder ( View itemView ) {
            super ( itemView );
            mainView = itemView;
            img = itemView.findViewById ( R.id.artist_item_img );
            menu = itemView.findViewById ( R.id.artist_item_menu );
            name = itemView.findViewById ( R.id.artist_item_name );
            songsButton = itemView.findViewById ( R.id.artist_song_button );
            shuffleButton = itemView.findViewById ( R.id.artist_shuffle_button );
            expandedArea = itemView.findViewById ( R.id.expanded_area );
            songCount = itemView.findViewById ( R.id.artist_item_song_count );
            rv = itemView.findViewById ( R.id.artist_sub_rv );
        }
    }

}
