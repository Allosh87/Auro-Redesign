package com.allosh.xtraplayer.utils.adapters;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import com.allosh.xtraplayer.ui.layouts.fragments.SongsListFragment;
import com.allosh.xtraplayer.ui.layouts.fragments.AlbumsListFragment;
import com.allosh.xtraplayer.ui.layouts.fragments.ArtistListFragment;
import com.allosh.xtraplayer.ui.layouts.fragments.PlaylistListFragment;

public class MainAdapter extends FragmentPagerAdapter {

    private Map<Integer, String> mFragmentTags;
    private FragmentManager mFragmentManager;

    private ArrayList<Fragment> fragments;

	private String tabTitles[] = new String[] {"Songs", "Albums", "Artists", "Playlists"};


    public MainAdapter ( FragmentManager fm ) {
        super ( fm );

        fragments = new ArrayList<> ( );

        mFragmentManager = fm;
        mFragmentTags = new HashMap<> ( );

    }

	@Override
    public Fragment getItem ( int position ) {
        switch ( position ) {

            case 0:
			return new SongsListFragment ( );

            case 1:
			return new AlbumsListFragment ( );

            case 2:
			return new ArtistListFragment ( );

			case 3:
			return new PlaylistListFragment ( );

        }

        return null;

    }

    @Override
    public Object instantiateItem ( ViewGroup container, int position ) {
        Object obj = super.instantiateItem ( container, position );
        if ( obj instanceof Fragment ) {
            Fragment f = (Fragment) obj;
            String tag = f.getTag ( );
            mFragmentTags.put ( position, tag );
        }
        return obj;
    }

    public Fragment getFragment ( int position ) {
        String tag = mFragmentTags.get ( position );
        if ( tag == null )
            return null;
        return mFragmentManager.findFragmentByTag ( tag );
    }

    @Override
    public CharSequence getPageTitle ( int position ) {

        return tabTitles [ position ];

    }

    @Override
    public int getCount ( ) {
        return 4;
    }
}

