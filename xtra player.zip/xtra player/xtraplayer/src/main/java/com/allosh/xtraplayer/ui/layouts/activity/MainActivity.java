package com.allosh.xtraplayer.ui.layouts.activity;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.os.Handler;
import android.speech.RecognizerIntent;
import android.support.annotation.AnimRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.allosh.xtraplayer.R;
import com.allosh.xtraplayer.service.PlayerService;
import com.allosh.xtraplayer.ui.layouts.fragments.AlbumsListFragment;
import com.allosh.xtraplayer.ui.layouts.fragments.ArtistListFragment;
import com.allosh.xtraplayer.ui.layouts.fragments.PlayerFragment;
import com.allosh.xtraplayer.ui.layouts.fragments.PlaylistListFragment;
import com.allosh.xtraplayer.ui.layouts.fragments.SearchViewFragment;
import com.allosh.xtraplayer.ui.layouts.fragments.SongsListFragment;
import com.allosh.xtraplayer.ui.layouts.fragments.UpNextFragment;
//import com.architjn.xtraplayer.ui.widget.slidinguppanel.SlidingUpPanelLayout;
import com.allosh.xtraplayer.utils.adapters.AlbumListAdapter;

import com.lapism.searchview.SearchView;

import java.util.List;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import com.allosh.xtraplayer.utils.adapters.MainAdapter;
import com.allosh.xtraplayer.MyPlayerApplication;
import android.util.Log;
import com.github.florent37.materialviewpager.MaterialViewPager;
import android.support.v4.app.FragmentStatePagerAdapter;
import com.github.florent37.materialviewpager.header.HeaderDesign;
import android.support.v7.app.ActionBar;
import com.allosh.xtraplayer.utils.PermissionChecker;
import android.support.v4.content.ContextCompat;
import android.content.pm.PackageManager;
import android.support.v4.app.ActivityCompat;
import android.Manifest;
import android.support.v7.app.AlertDialog;
import android.content.DialogInterface;
import com.sothree.slidinguppanel.SlidingUpPanelLayout;


import com.github.florent37.materialviewpager.MaterialViewPagerHelper;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {

	private static final int PERMISSION_READ_EXTERNAL_STORAGE = 0;
	
	private MaterialViewPager mViewPager;
	private SlidingUpPanelLayout mSlidingPanel;
    private FragmentName mCurrentFragment;
    private Toolbar mToolbar;
    private int mCurrentItem = -1;
    private SongsListFragment mSongFragment;
    private AlbumsListFragment mAlbumFragment;
    private ArtistListFragment mArtistFragment;
    private PlaylistListFragment mPlaylistFragment;
    private SearchViewFragment mSearchViewFragment;
    private PlayerFragment playerFragment;
    private UpNextFragment upNextFragment;
    private SearchView searchView;


    public static boolean activityRunning = false;
    public FragmentName lastExpanded;
    public int lastItem;

	private FrameLayout mDrawerContent;
	

    @Override
    protected void onCreate ( @Nullable Bundle savedInstanceState ) {
        setTheme ( R.style.AppTheme_Main );
        super.onCreate ( savedInstanceState );
		MyPlayerApplication.Initializers ( this );
		Log.e ( "TAG", "Message" );
        //Start music player service
        startService ( new Intent ( this, PlayerService.class ) );

        setTheView ( );
		// setContentHolder ();
        activityRunning = true;
    }

	/*
	private void setContentHolder ( ) {
		setContentView( R.layout.activity_main_tabs );
		
		mDrawerContent = (FrameLayout) findViewById(R.id.drawer_content_container);
		
		View view = View.inflate(this , R.layout.activity_main_content, null);
		mDrawerContent.addView( view);
		
	}
	 */
	
	
	
	
	
	

    private void setTheView ( ) {

        setContentView ( R.layout.activity_main );
		setTitle ( "" );

		int permissionCheck = ContextCompat.checkSelfPermission ( MainActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE );
        if ( permissionCheck == PackageManager.PERMISSION_GRANTED ) {

			initializeTabs ( );

        } else {

            ActivityCompat.requestPermissions ( MainActivity.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE,
			Manifest.permission.WRITE_EXTERNAL_STORAGE}, PERMISSION_READ_EXTERNAL_STORAGE );
			
        }


        init ( );
        sendBroadcast ( new Intent ( PlayerService.ACTION_GET_SONG ) );

    }

	@Override
    public void onRequestPermissionsResult ( int requestCode, String[] permissions, int[] grantResults ) {
        switch ( requestCode ) {
            case PERMISSION_READ_EXTERNAL_STORAGE:

			if ( grantResults.length > 0 && grantResults [ 0 ] == PackageManager.PERMISSION_GRANTED ) {

				initializeTabs ( );

			} else {
				if ( ActivityCompat.shouldShowRequestPermissionRationale ( MainActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE ) ) {

					AlertDialog.Builder dialog = new AlertDialog.Builder ( this );
					dialog.setMessage ( " This app is a music player. Without proper permissions, it's useless. Please allow access to requested permissions ！" );
					dialog.setCancelable ( false );
					dialog.setPositiveButton ( "Request", new DialogInterface.OnClickListener ( ) {
						@Override
						public void onClick ( DialogInterface dialog, int which ) {

							ActivityCompat.requestPermissions ( MainActivity.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, PERMISSION_READ_EXTERNAL_STORAGE );
						}
					} );

					dialog.setNegativeButton ( "Exit", new DialogInterface.OnClickListener ( ) {
						@Override
						public void onClick ( DialogInterface dialog, int which ) {

							finishAffinity ( );
						}
					} );
					dialog.create ( ).show ( );
				}

			}
        }
    }

	private void initializeTabs ( ) {

		mViewPager = (MaterialViewPager) findViewById ( R.id.materialViewPager );
		mViewPager.getViewPager ( ).setAdapter ( new FragmentStatePagerAdapter ( getSupportFragmentManager ( ) ) {

            @Override
            public Fragment getItem ( int position ) {
                switch ( position % 4 ) {

                    case 0:
					return mSongFragment.newInstance ( );
                    case 1:
					return mAlbumFragment.newInstance ( );
                    case 2:
					return mArtistFragment.newInstance ( );
                    case 3:
					return mPlaylistFragment.newInstance ( );

					default:
					return mSongFragment.newInstance ( );
                }
            }

            @Override
            public int getCount ( ) {
                return 4;
            }

            @Override
            public CharSequence getPageTitle ( int position ) {
                switch ( position % 4 ) {
                    case 0:
					return "Songs";
                    case 1:
					return "Albums";
                    case 2:
					return "Artists";
                    case 3:
					return "Playlists";
                }
                return "";
            }
        } );

		/*
		 mViewPager.setMaterialViewPagerListener(new MaterialViewPager.Listener() {
		 @Override
		 public HeaderDesign getHeaderDesign(int page) {
		 switch (page) {

		 case 0:
		 return HeaderDesign.fromColorResAndUrl(
		 R.color.blue,
		 "http://www.hdiphonewallpapers.us/phone-wallpapers/540x960-1/540x960-mobile-wallpapers-hd-2218x5ox3.jpg");

		 case 1:
		 return HeaderDesign.fromColorResAndUrl(
		 R.color.blue,
		 "http://www.hdiphonewallpapers.us/phone-wallpapers/540x960-1/540x960-mobile-wallpapers-hd-2218x5ox3.jpg");

		 case 2:
		 return HeaderDesign.fromColorResAndUrl(
		 R.color.cyan,
		 "http://www.droid-life.com/wp-content/uploads/2014/10/lollipop-wallpapers10.jpg");

		 case 3:
		 return HeaderDesign.fromColorResAndUrl(
		 R.color.blue,
		 "http://www.hdiphonewallpapers.us/phone-wallpapers/540x960-1/540x960-mobile-wallpapers-hd-2218x5ox3.jpg");

		 }

		 //execute others actions if needed (ex : modify your header logo)

		 return null;
		 }
		 });*/

        mViewPager.getViewPager ( ).setOffscreenPageLimit ( mViewPager.getViewPager ( ).getAdapter ( ).getCount ( ) );
        mViewPager.getPagerTitleStrip ( ).setViewPager ( mViewPager.getViewPager ( ) );
		//MaterialViewPagerHelper.getAnimatorContext(this).onMaterialScrolled(null,0);

		Toolbar toolbar = mViewPager.getToolbar ( );

		if ( toolbar != null ) {
			setSupportActionBar ( toolbar );

			ActionBar actionBar = getSupportActionBar ( );
			actionBar.setDisplayHomeAsUpEnabled ( false );
			actionBar.setDisplayShowHomeEnabled ( false );
			actionBar.setDisplayShowTitleEnabled ( true );
			actionBar.setDisplayUseLogoEnabled ( false );
			actionBar.setHomeButtonEnabled ( false );
		}


		//checkPermissions();

		int permissionCheck = ContextCompat.checkSelfPermission ( MainActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE );
        if ( permissionCheck == PackageManager.PERMISSION_GRANTED ) {

			init ( );
			sendBroadcast ( new Intent ( PlayerService.ACTION_GET_SONG ) );

        } else {

            ActivityCompat.requestPermissions ( MainActivity.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE,
			Manifest.permission.WRITE_EXTERNAL_STORAGE}, PERMISSION_READ_EXTERNAL_STORAGE );
        }


	}




    private void init ( ) {

		mSlidingPanel = ( SlidingUpPanelLayout) findViewById ( R.id.sliding_layout );
		//    slidingUpPanelLayout = (SlidingUpPanelLayout) findViewById(R.id.sliding_layout);
        initSmallPlayer ( );
        new Handler ( ).postDelayed ( new Runnable ( ) {
            @Override
            public void run ( ) {
                if ( getIntent ( ).getBooleanExtra ( "openPanel", false ) ) {
                    //   slidingUpPanelLayout.expandPanel();
					mSlidingPanel.setPanelState ( SlidingUpPanelLayout.PanelState.EXPANDED );

                }
            }
        }, 2000 );
        initSearch ( );
    }

    private void initSearch ( ) {
        searchView = (SearchView) findViewById ( R.id.search_view );
        searchView.setVoiceSearch ( true );
        mSearchViewFragment = new SearchViewFragment ( );
        mSearchViewFragment.setSearchView ( searchView );
        searchView.setOnSearchViewListener ( new SearchView.SearchViewListener ( ) {

            @Override
            public void onSearchViewShown ( ) {
                if ( mCurrentFragment != FragmentName.Search ) {
                    lastExpanded = mCurrentFragment;
                    lastItem = mCurrentItem;
                    mCurrentFragment = FragmentName.Search;
                }
				//       fragmentSwitcher(searchViewFragment, -1, FragmentName.Search,
				//               android.R.anim.fade_in, android.R.anim.fade_out);
            }

            @Override
            public void onSearchViewClosed ( ) {
            }
        } );

    }
	/*
	 private void initDrawer() {
     //   drawerLayout = (DrawerLayout) findViewById(R.id.drawerLayout);
     //    navigationView = (NavigationView) findViewById(R.id.main_navigationview);
	 navigationHeader = navigationView.getHeaderView(0);
	 navigationHeader.setOnClickListener(new View.OnClickListener() {
	 @Override
	 public void onClick(View view) {
	 if (slidingUpPanelLayout.isPanelHidden())
	 return;
	 slidingUpPanelLayout.expandPanel();
	 drawerLayout.closeDrawer(GravityCompat.START);
	 }
	 });
	 navigationView.setCheckedItem(R.id.navigation_albums);
	 navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
	 @Override
	 public boolean onNavigationItemSelected(MenuItem item) {
	 switch (item.getItemId()) {
	 case R.id.navigation_songs:
	 if (songFragment == null)
	 songFragment = new SongsListFragment();
	 fragmentSwitcher(songFragment, item.getItemId(),
	 FragmentName.Songs,
	 android.R.anim.slide_in_left, android.R.anim.slide_out_right);
	 closeDrawer();
	 break;
	 case R.id.navigation_albums:
	 if (albumFragment == null)
	 albumFragment = new AlbumsListFragment();
	 fragmentSwitcher(albumFragment, item.getItemId(),
	 FragmentName.Albums,
	 android.R.anim.slide_in_left, android.R.anim.slide_out_right);
	 closeDrawer();
	 break;
	 case R.id.navigation_artist:
	 if (artistFragment == null)
	 artistFragment = new ArtistListFragment();
	 fragmentSwitcher(artistFragment, item.getItemId(),
	 FragmentName.Artists,
	 android.R.anim.slide_in_left, android.R.anim.slide_out_right);
	 closeDrawer();
	 break;
	 case R.id.navigation_playlist:
	 if (playlistFragment == null)
	 playlistFragment = new PlaylistListFragment();
	 fragmentSwitcher(playlistFragment, item.getItemId(),
	 FragmentName.Playlists,
	 android.R.anim.slide_in_left, android.R.anim.slide_out_right);
	 closeDrawer();
	 break;
	 }
	 return true;
	 }
	 });

	 ActionBarDrawerToggle drawerToggle = new ActionBarDrawerToggle(this, drawerLayout,
	 toolbar, 0, 0) {

	 @Override
	 public void onDrawerClosed(View drawerView) {
	 super.onDrawerClosed(drawerView);
	 invalidateOptionsMenu();
	 syncState();
	 }

	 @Override
	 public void onDrawerOpened(View drawerView) {
	 super.onDrawerOpened(drawerView);
	 invalidateOptionsMenu();
	 syncState();
	 }
	 };
	 drawerLayout.setDrawerListener(drawerToggle);
	 drawerToggle.syncState();
	 }

	 private void closeDrawer() {
	 if (slidingUpPanelLayout.isPanelExpanded())
	 slidingUpPanelLayout.collapsePanel();
	 }


	 @Override
	 public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
	 @NonNull int[] grantResults) {
	 try {
	 albumFragment.onRequestPermissionsResult(requestCode, permissions, grantResults);
	 } catch (NullPointerException e) {
	 e.printStackTrace();
	 }
	 }
	 */
	/*
	 @Override
	 public void onRequestPermissionsResult ( int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults ) {
	 super.onRequestPermissionsResult ( requestCode, permissions, grantResults );
	 }
	 */

    @Override
    protected void onResume ( ) {
        super.onResume ( );
        if ( mSongFragment != null ) {
            playerFragment.onResume ( );
        }
        activityRunning = true;
        AlbumListAdapter.onceAnimated = false;
    }

    @Override
    protected void onPause ( ) {
        super.onPause ( );
        activityRunning = false;
    }

	
	 public void fragmentSwitcher(Fragment fragment, int itemId,
	 FragmentName fname, @AnimRes int animationEnter,
	 @AnimRes int animationExit) {
	 mCurrentFragment = fname;
	 if (mCurrentItem == itemId) {
	 // Don't allow re-selection of the currently active item
	 return;
	 }
	 mCurrentItem = itemId;
	 if (getSupportActionBar() != null)
	 getSupportActionBar().setTitle(String.valueOf(fname));

	 getSupportFragmentManager().beginTransaction()
	 .setCustomAnimations(animationEnter, animationExit)
	 .replace(R.id.activity_mainFrameLayout, fragment)
	 .commitAllowingStateLoss();

	 }
	 

    @Override
    protected void onDestroy ( ) {
        super.onDestroy ( );
        activityRunning = false;
    }

    @Override
    public boolean onCreateOptionsMenu ( Menu menu ) {
        getMenuInflater ( ).inflate ( R.menu.main_menu, menu );
        return true;
    }

    @Override
    public boolean onOptionsItemSelected ( MenuItem item ) {
        switch ( item.getItemId ( ) ) {
            case R.id.action_search: {
                searchView.showSearch ( findViewById ( R.id.action_search ), true );
                return true;
            }
            default:
			return super.onOptionsItemSelected ( item );
        }
    }

    private void initSmallPlayer ( ) {
        playerFragment = new PlayerFragment ( );
        upNextFragment = new UpNextFragment ( );
        playerFragment.setUpNextFragment ( upNextFragment );
        // playerFragment.setNavigationHeader(navigationHeader);
        // playerFragment.setSlidingUpPanelLayout(slidingUpPanelLayout);
		playerFragment.setSlidingUpPanelLayout ( mSlidingPanel );
        FragmentManager fragmentManager1 = getSupportFragmentManager ( );
        fragmentManager1.beginTransaction ( )
		.replace ( R.id.panel_holder, playerFragment )
		.commitAllowingStateLoss ( );
    }

    public void killActivity ( ) {
        super.onBackPressed ( );
    }


    public Fragment getFragmentFromName ( FragmentName name ) {
        switch ( name ) {
            case Songs:
			return mSongFragment;
			
            case Albums:
			return mAlbumFragment;
			
            case Artists:
			return mArtistFragment;
			
            case Playlists:
			return mPlaylistFragment;
        }
        return null;
    }


    public void setStatusBarColor ( int color ) {
        getWindow ( ).setStatusBarColor ( color );
    }


	public void onBackPressed ( ) {

		if ( mSlidingPanel != null && ( mSlidingPanel.getPanelState ( ) == SlidingUpPanelLayout.PanelState.EXPANDED || mSlidingPanel.getPanelState ( ) == SlidingUpPanelLayout.PanelState.ANCHORED ) ) {

			mSlidingPanel.setPanelState ( SlidingUpPanelLayout.PanelState.COLLAPSED );

		} else {

			super.onBackPressed ( );

		}



		/*
		 //   if ( mDrawer != null ) {
		 if ( slidingUpPanelLayout != null && slidingUpPanelLayout.isPanelExpanded ( )
		 //|| mSlidingPanel.getPanelState ( ) == SlidingUpPanelLayout.PanelState.ANCHORED ) )
		 ) {

		 slidingUpPanelLayout.collapsePanel();
		 //( SlidingUpPanelLayout.PanelState.COLLAPSED );
		 } else
		 super.onBackPressed ( );
		 */

    }


	/*

	 @Override
	 public void onBackPress() {
	 if (searchView.isSearchOpen()) {
	 searchView.closeSearch(true);
	 return;
	 }
	 if (slidingUpPanelLayout.isPanelExpanded()) {
	 playerFragment.onBackPressed();
	 upNextFragment.onBackPressed();
	 return;
	 }
	 switch (currentFragment) {
	 case Songs:
	 songFragment.onBackPress();
	 break;
	 case Albums:
	 albumFragment.onBackPress();
	 break;
	 case Artists:
	 artistFragment.onBackPress();
	 break;
	 case Playlists:
	 playlistFragment.onBackPress();
	 break;
	 case Search:
	 //    searchViewFragment.onBackPressed();
	 break;
	 }
	 }*/

    @Override
    protected void onActivityResult ( int requestCode, int resultCode, Intent data ) {
        if ( requestCode == SearchView.SPEECH_REQUEST_CODE && resultCode == RESULT_OK ) {
            List<String> matches = data.getStringArrayListExtra ( RecognizerIntent.EXTRA_RESULTS );
            if ( matches != null && matches.size ( ) > 0 ) {
                String searchWrd = matches.get ( 0 );
                if ( !TextUtils.isEmpty ( searchWrd ) ) {
                    searchView.setQuery ( searchWrd, false );
                }
            }
            return;
        }
        super.onActivityResult ( requestCode, resultCode, data );
    }


    @Override
    public boolean onKeyDown ( int keyCode, KeyEvent event ) {
        if ( event.getKeyCode ( ) == KeyEvent.KEYCODE_BACK ) {
            onBackPressed ( );
        }
        if ( playerFragment != null )
            return playerFragment.onKeyEvent ( event );
        return super.onKeyDown ( keyCode, event );
    }

    public enum FragmentName {
        Albums, Songs, Artists, Playlists, Search
		}

}
