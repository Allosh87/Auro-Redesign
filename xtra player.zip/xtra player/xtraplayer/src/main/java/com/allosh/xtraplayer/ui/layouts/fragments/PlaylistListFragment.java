package com.allosh.xtraplayer.ui.layouts.fragments;

import android.Manifest;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import com.afollestad.materialdialogs.MaterialDialog;
import com.allosh.xtraplayer.R;
import com.allosh.xtraplayer.utils.PermissionChecker;
import com.allosh.xtraplayer.utils.adapters.PlaylistListAdapter;
import com.allosh.xtraplayer.utils.decorations.SimpleDividerItemDecoration;
import com.allosh.xtraplayer.utils.handlers.PlaylistDBHelper;
import com.allosh.xtraplayer.utils.items.Playlist;

import java.util.ArrayList;
import com.github.florent37.materialviewpager.header.MaterialViewPagerHeaderDecorator;

/**
 * Created by architjn on 27/11/15.
 */
public class PlaylistListFragment extends Fragment {

    private Context context;
    private View mainView;
    private RecyclerView rv;
    private PlaylistListAdapter mAdapter;
    private PermissionChecker permissionChecker;
    private PlaylistDBHelper playlistDBHelper;
    private View emptyView;

	public static PlaylistListFragment newInstance() {
        return new PlaylistListFragment();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_playlist,
                container, false);
        context = view.getContext();
        mainView = view;
        init();
        return view;
    }

    private void init() {
        rv = mainView.findViewById(R.id.playlistContainer);
        emptyView = mainView.findViewById(R.id.playlist_empty_view);
        playlistDBHelper = new PlaylistDBHelper(context);
		loadPlaylists();
        setHasOptionsMenu(true);
    }

    

    private void loadPlaylists() {
		
		ArrayList<Playlist> mPlaylists = playlistDBHelper.getAllPlaylist();
		mAdapter = new PlaylistListAdapter(context, mPlaylists, this);
		
		
	//	} else {
			
      //      listNoMoreEmpty();
		
		rv.setLayoutManager(new LinearLayoutManager(context));
		rv.setHasFixedSize(true);
		rv.addItemDecoration(new MaterialViewPagerHeaderDecorator());
        
        rv.setAdapter(mAdapter);
		
		/*
		rv.setOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                adapter.recyclerScrolled();
            }

            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);

                if (newState == AbsListView.OnScrollListener.SCROLL_STATE_FLING) {
                    // Do something
                } else if (newState == AbsListView.OnScrollListener.SCROLL_STATE_TOUCH_SCROLL) {
                    // Do something
                } else {
                    // Do something
                }
            }
        });*/
		
		if (mPlaylists.size() == 0) {

			listIsEmpty();
			
			}
        
    }

    public void listIsEmpty() {
        emptyView.setVisibility(View.VISIBLE);
        rv.setVisibility(View.GONE);
    }

    public void listNoMoreEmpty() {
        rv.setVisibility(View.VISIBLE);
        emptyView.setVisibility(View.GONE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        permissionChecker.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    public void onBackPress() {
        mAdapter.onBackPressed();
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        // TODO Add your menu entries here
        inflater.inflate(R.menu.playlist_fragment, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

    private void newPlaylistDialog() {
        new MaterialDialog.Builder(context)
                .title(R.string.new_playlist)
                .input(null, null, new MaterialDialog.InputCallback() {
                    @Override
                    public void onInput(MaterialDialog dialog, CharSequence input) {
						
                        if (!input.toString().matches("")) {
                            playlistDBHelper.createPlaylist(input.toString());
                            listNoMoreEmpty();
                            mAdapter.updateNewList(playlistDBHelper.getAllPlaylist());
							mAdapter.notifyDataSetChanged();
                        }
                    }
					
                }).show();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
			
            case R.id.menu_playlist_fragment_add:
                newPlaylistDialog();
                return false;
				
            default:
			
                break;
        }

        return false;
    }


}
