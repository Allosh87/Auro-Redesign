package com.allosh.xtraplayer.ui.layouts.activity;

public class SplashActivity
{
}
