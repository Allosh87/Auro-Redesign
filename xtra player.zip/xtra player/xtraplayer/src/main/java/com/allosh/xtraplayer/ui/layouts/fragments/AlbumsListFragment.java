package com.allosh.xtraplayer.ui.layouts.fragments;

import android.Manifest;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;
import com.allosh.xtraplayer.R;
import com.allosh.xtraplayer.ui.layouts.activity.MainActivity;
import com.allosh.xtraplayer.utils.ListSongs;
import com.allosh.xtraplayer.utils.PermissionChecker;
import com.allosh.xtraplayer.utils.Utils;
import com.allosh.xtraplayer.utils.adapters.AlbumListAdapter;
import com.allosh.xtraplayer.utils.decorations.AlbumListSpacesItemDecoration;
import com.allosh.xtraplayer.utils.items.Album;

import java.util.ArrayList;
import com.simplecityapps.recyclerview_fastscroll.views.FastScrollRecyclerView;
import com.github.florent37.materialviewpager.header.MaterialViewPagerHeaderDecorator;


public class AlbumsListFragment extends Fragment {

    private Context mContext;
    private View mView;
    private FastScrollRecyclerView mRecyclerView;
    private AlbumListAdapter mAdapter;
    private PermissionChecker mPermissionChecker;
    private View mEmptyView;

	public static AlbumsListFragment newInstance ( ) {
        return new AlbumsListFragment ( );
    }

    @Override
    public View onCreateView ( LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState ) {
        View view = inflater.inflate ( R.layout.fragment_albums, container, false );
        mView = view;
        System.gc ( );
        mContext = mView.getContext ( );
		
        initViews ( );
        return view;
    }

    private void initViews ( ) {

        mRecyclerView = mView.findViewById ( R.id.albumsListContainer );
        mEmptyView = mView.findViewById ( R.id.album_empty_view );
        AlbumListAdapter.onceAnimated = false;
		loadAlbums ( );

    }

    private void loadAlbums ( ) {

        new Thread ( new Runnable ( ) {
            public void run ( ) {

				final ArrayList<Album> albumList = ListSongs.getAlbumList ( mContext );
                final GridLayoutManager gridLayoutManager = new GridLayoutManager ( getActivity ( ), 2 );

                getActivity ( ).runOnUiThread ( new Runnable ( ) {
                    @Override
                    public void run ( ) {

						mRecyclerView.setLayoutManager ( gridLayoutManager );
						mRecyclerView.setHasFixedSize ( true );
						mRecyclerView.addItemDecoration ( new MaterialViewPagerHeaderDecorator ( ) );
                        mAdapter = new AlbumListAdapter ( getActivity ( ), mView.getContext ( ), albumList, mRecyclerView );
                        mRecyclerView.setAdapter ( mAdapter );

                    }
                } );

                if ( albumList.size ( ) < 1 ) {

                    getActivity ( ).runOnUiThread ( new Runnable ( ) {

                        @Override
                        public void run ( ) {

                            listIsEmpty ( );
                        }
                    } );
                }
            }
			
        } ).start ( );

    }

    public void listIsEmpty ( ) {
        mEmptyView.setVisibility ( View.VISIBLE );
        mRecyclerView.setVisibility ( View.GONE );
    }

    public int dpToPx ( int dp ) {
        DisplayMetrics displayMetrics = mContext.getResources ( ).getDisplayMetrics ( );
        return Math.round ( dp * ( displayMetrics.xdpi / DisplayMetrics.DENSITY_DEFAULT ) );
    }

    @Override
    public void onDestroy ( ) {
        super.onDestroy ( );
		//    Async.cancelAll();
    }

    public void onRequestPermissionsResult ( int requestCode, @NonNull String[] permissions,
	@NonNull int[] grantResults ) {
        mPermissionChecker.onRequestPermissionsResult ( requestCode, permissions, grantResults );
    }

    public void onBackPress ( ) {
        ( (MainActivity) getActivity ( ) ).killActivity ( );
    }

}
