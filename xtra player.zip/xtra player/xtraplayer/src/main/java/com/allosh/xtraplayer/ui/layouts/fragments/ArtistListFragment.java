package com.allosh.xtraplayer.ui.layouts.fragments;

import android.Manifest;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;

// import com.afollestad.async.Async;
import com.allosh.xtraplayer.R;
import com.allosh.xtraplayer.utils.ListSongs;
import com.allosh.xtraplayer.utils.PermissionChecker;
import com.allosh.xtraplayer.utils.decorations.SimpleDividerItemDecoration;
import com.allosh.xtraplayer.utils.adapters.ArtistsListAdapter;
import com.allosh.xtraplayer.utils.items.Artist;

import java.util.ArrayList;
import com.simplecityapps.recyclerview_fastscroll.views.FastScrollRecyclerView;
import com.github.florent37.materialviewpager.header.MaterialViewPagerHeaderDecorator;

/**
 * Created by architjn on 27/11/15.
 */
public class ArtistListFragment extends Fragment {

    private Context context;
    private View mainView;
    private FastScrollRecyclerView rv;
    private ArtistsListAdapter adapter;
    private PermissionChecker permissionChecker;
    private View emptyView;

	public static ArtistListFragment newInstance() {
        return new ArtistListFragment();
    }
	
	
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_artists,
                container, false);
        context = view.getContext();
        mainView = view;
        init();
        return view;
    }

    private void init() {
        rv = mainView.findViewById(R.id.artistsListContainer);
        emptyView = mainView.findViewById(R.id.artist_empty_view);
     //   checkPermissions();
		loadArtists();
    }

    private void checkPermissions() {
        permissionChecker = new PermissionChecker(context, getActivity(), mainView);
        permissionChecker.check(Manifest.permission.WRITE_EXTERNAL_STORAGE,
                getResources().getString(R.string.storage_permission),
                new PermissionChecker.OnPermissionResponse() {
                    @Override
                    public void onAccepted() {
                        
						loadArtists ();
						
                    }

                    @Override
                    public void onDecline() {
                        getActivity().finish();
                    }
                });
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
   //     Async.cancelAll();
    }

    private void loadArtists() {
		
        rv.setLayoutManager(new LinearLayoutManager(context));
		rv.setHasFixedSize(true);
		rv.addItemDecoration(new MaterialViewPagerHeaderDecorator());
		
        ArrayList<Artist> mArtists = ListSongs.getArtistList(context);
        adapter = new ArtistsListAdapter(context, mArtists, this);
        rv.setAdapter(adapter);
		
        rv.setOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                adapter.recyclerScrolled();
            }

            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);

                if (newState == AbsListView.OnScrollListener.SCROLL_STATE_FLING) {
                    // Do something
                } else if (newState == AbsListView.OnScrollListener.SCROLL_STATE_TOUCH_SCROLL) {
                    // Do something
                } else {
                    // Do something
                }
            }
        });
		
        if (mArtists.size() < 1)
            listIsEmpty();
    }

    public void listIsEmpty() {
        emptyView.setVisibility(View.VISIBLE);
        rv.setVisibility(View.GONE);
    }

    public void listNoMoreEmpty() {
        rv.setVisibility(View.VISIBLE);
        emptyView.setVisibility(View.GONE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        permissionChecker.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    public void onBackPress() {
        adapter.onBackPressed();
    }

}
