package com.allosh.xtraplayer;

import android.app.Application;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.provider.Settings;
import com.facebook.drawee.backends.pipeline.Fresco;

public class MyPlayerApplication extends Application {


   
    private static Context mContext;

    public static Context getInstance() {
        return mContext;
    }
    

    public static int getVersionCode() {
        try {
            PackageInfo pInfo = MyPlayerApplication.getInstance().getPackageManager().getPackageInfo(MyPlayerApplication.getInstance().getPackageName(), 0);
            int version = pInfo.versionCode;
            return version;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
            return 0;
        }
    }

    public static String getVersionName() {
        try {
            PackageInfo pInfo = MyPlayerApplication.getInstance().getPackageManager().getPackageInfo(MyPlayerApplication.getInstance().getPackageName(), 0);
            String version = pInfo.versionName;
            return version;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
            return "";
        }
    }


    /*
     * Returns the status bar height for the current layout configuration.
     */
    public static int getStatusBarHeight(Context context) {
        int result = 0;
        int resourceId = context.getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (resourceId > 0) {
            result = context.getResources().getDimensionPixelSize(resourceId);
        }
        return result;
    }

    /*
     * Returns the navigation bar height for the current layout configuration.
     */
    public static int getNavigationBarHeight(Context context) {
        Resources resources = context.getResources();
        int resourceId = resources.getIdentifier("navigation_bar_height", "dimen", "android");
        if (resourceId > 0) {
            return resources.getDimensionPixelSize(resourceId);
        }

        return 0;
    }

    public static String getAndroidId() {
        return Settings.Secure.ANDROID_ID;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        mContext = getApplicationContext();

       
    }

	public static void Initializers(Context context){
        Fresco.initialize(context);
    }



}


