package com.allosh.xtraplayer.utils;

public class Constants
{
	
	
	
	
	
}
