package com.allosh.xtraplayer.utils.adapters;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v7.widget.PopupMenu;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;
import com.allosh.xtraplayer.R;
import com.allosh.xtraplayer.ui.layouts.activity.MainActivity;
import com.allosh.xtraplayer.utils.items.Song;
import java.io.File;
import java.util.Collections;
import java.util.ArrayList;
import com.facebook.drawee.view.SimpleDraweeView;
import com.allosh.xtraplayer.utils.ListSongs;
import com.allosh.xtraplayer.utils.adapters.CurrentPlaylistQ.MyViewHolder;
import com.allosh.xtraplayer.utils.Constants;

public class CurrentPlaylistQ extends RecyclerView.Adapter<CurrentPlaylistQ.MyViewHolder>  {

    private Context context;
    private Activity mActivity;
    private LayoutInflater inflater;
	
	private ArrayList<Song> mSongs;
	

    public CurrentPlaylistQ(Context context, Activity mActivity, ArrayList<Song> data ){
        this.context = context;
        this.mActivity = mActivity;
		this.mSongs = data;
        inflater = LayoutInflater.from(context);
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.songs_list_item, parent, false);
        return new MyViewHolder(view);
    }
    public void onBindViewHolder(MyViewHolder holder, final int position) {
		
		Song song = mSongs.get(position);
		holder.name.setText(song.getName());
        holder.artistName.setText(mSongs.get(position).getArtist());
        holder.mainView.setElevation(0);

        setAlbumArt ( holder, song ) ;
		
    }

	private void setAlbumArt ( CurrentPlaylistQ.MyViewHolder holder, Song song ) {
		Uri albumArt = ListSongs.getAlbumArtUri ( song.getAlbumId() ) ;

		if ( albumArt != null ) {

			holder.img.setImageURI ( albumArt );

		} else {
			
			//holder.img.setImageResource ( R.drawable.default_art );
			
		}
		
	}

    
    public int getItemCount() {
		
        return mSongs.size();
		
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

		public TextView name, artistName;
        public View mainView, menu;
        public SimpleDraweeView img;

        public MyViewHolder(View itemView) {
            super(itemView);
            mainView = itemView;
            img = itemView.findViewById(R.id.song_item_img);
            name = (TextView) itemView.findViewById(R.id.song_item_name);
            menu = itemView.findViewById(R.id.song_item_menu);
            artistName = (TextView) itemView.findViewById(R.id.song_item_artist);
        


        }

        
    }
	
	
}

