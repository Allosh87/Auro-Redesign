package com.allosh.xtraplayer.service;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.MediaPlayer;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.widget.Toast;

import com.allosh.xtraplayer.R;
import com.allosh.xtraplayer.ui.layouts.activity.MainActivity;
import com.allosh.xtraplayer.ui.layouts.fragments.PlayerFragment;
import com.allosh.xtraplayer.utils.handlers.NotificationHandler;
import com.allosh.xtraplayer.utils.handlers.PlayerHandler;

import java.io.IOException;
import com.allosh.xtraplayer.service.PlayerService.ListType;
import java.util.ArrayList;
import com.allosh.xtraplayer.utils.items.Song;
import android.preference.PreferenceManager;

/**
 * Created by architjn on 11/12/15.
 */
public class PlayerService extends Service {

    public static final String ACTION_PLAY_SINGLE = "ACTION_PLAY_SINGLE";
    public static final String ACTION_PLAY_ALL_SONGS = "ACTION_PLAY_ALL_SONGS";
    public static final String ACTION_PLAY_ALBUM = "ACTION_PLAY_ALBUM";
    public static final String ACTION_PLAY_PLAYLIST = "ACTION_PLAY_PLAYLIST";
    public static final String ACTION_PLAY_ARTIST = "ACTION_PLAY_ARTIST";
    public static final String ACTION_GET_SONG = "ACTION_GET_SONG";
    public static final String ACTION_NOTI_CLICK = "ACTION_NOTI_CLICK";
    public static final String ACTION_NOTI_REMOVE = "ACTION_NOTI_REMOVE";
    public static final String ACTION_CHANGE_SONG = "ACTION_CHANGE_SONG";
    public static final String ACTION_SEEK_SONG = "ACTION_SEEK_SONG";
    public static final String ACTION_NEXT_SONG = "ACTION_NEXT_SONG";
    public static final String ACTION_PREV_SONG = "ACTION_PREV_SONG";
    public static final String ACTION_PAUSE_SONG = "ACTION_PAUSE_SONG";
    public static final String ACTION_ADD_QUEUE = "ACTION_ADD_QUEUE";
	
	public static final String SAVED_POSITION = "POSITION";
    public static final String SAVED_POSITION_IN_TRACK = "POSITION_IN_TRACK";
    
	
    private PlayerHandler musicPlayerHandler;
    private Context context;
    private NotificationHandler notificationHandler;
    private BroadcastReceiver playerServiceBroadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            try {
                handleBroadcastReceived(context, intent);
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(PlayerService.this, R.string.cant_play_song, Toast.LENGTH_SHORT).show();
            }
        }
    };

	private PlayerService.ListType listType;
	
	private ArrayList<Song> playingQueue = new ArrayList<>();
    private ArrayList<Song> originalPlayingQueue = new ArrayList<>();
	private boolean queuesRestored;

	private int position = -1;
	
	
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        context = this;
        if (musicPlayerHandler == null)
            musicPlayerHandler = new PlayerHandler(context, this);
			
		//restoreQueuesAndPositionIfNecessary();
		
        IntentFilter filter = new IntentFilter();
        filter.addAction(ACTION_PLAY_SINGLE);
        filter.addAction(ACTION_PLAY_ALL_SONGS);
        filter.addAction(ACTION_PLAY_ALBUM);
        filter.addAction(ACTION_GET_SONG);
        filter.addAction(ACTION_NEXT_SONG);
        filter.addAction(ACTION_PREV_SONG);
        filter.addAction(ACTION_PAUSE_SONG);
        filter.addAction(ACTION_SEEK_SONG);
        filter.addAction(ACTION_CHANGE_SONG);
        filter.addAction(ACTION_PLAY_PLAYLIST);
        filter.addAction(ACTION_PLAY_ARTIST);
        filter.addAction(ACTION_NOTI_CLICK);
        filter.addAction(ACTION_NOTI_REMOVE);
        filter.addAction(ACTION_ADD_QUEUE);
        registerReceiver(playerServiceBroadcastReceiver, filter);
        notificationHandler = new NotificationHandler(context, this);
        return START_NOT_STICKY;
    }

    private void handleBroadcastReceived(Context context, final Intent intent) throws IOException {
		
		if (intent != null) {
            if (intent.getAction() != null) {
                restoreQueuesAndPositionIfNecessary();
				
				}
			}
		
        switch (intent.getAction()) {
            case ACTION_PLAY_SINGLE:
                musicPlayerHandler.playSingleSong(intent.getLongExtra("songId", 0));
                listType = ListType.SINGLE;
                updatePlayer();
                break;
            case ACTION_PLAY_ALL_SONGS:
                playAllSongs(intent);
                break;
            case ACTION_PLAY_ALBUM:
                playAlbumSongs(intent);
                break;
            case ACTION_GET_SONG:
                try {
                    updatePlayer();
                } catch (ArrayIndexOutOfBoundsException e) {
                    e.printStackTrace();
                }
                break;
            case ACTION_NEXT_SONG:
                musicPlayerHandler.playNextSong(musicPlayerHandler.getCurrentPlayingPos() + 1);
                break;
            case ACTION_PREV_SONG:
                musicPlayerHandler.playPrevSong(musicPlayerHandler.getCurrentPlayingPos() - 1);
                updatePlayer();
                break;
            case ACTION_PAUSE_SONG:
                musicPlayerHandler.playOrStop(notificationHandler);
                updatePlayer();
                break;
            case ACTION_SEEK_SONG:
                musicPlayerHandler.seek(intent.getIntExtra("seek", 0));
                break;
            case ACTION_CHANGE_SONG:
                musicPlayerHandler.playNextSong(intent.getIntExtra("pos", 0));
                break;
            case ACTION_PLAY_PLAYLIST:
                musicPlayerHandler.playPlaylist(intent.getIntExtra("id", 0),
                        intent.getIntExtra("pos", 0));
                listType = ListType.PLAYLIST;
                updatePlayer();
                break;
            case ACTION_PLAY_ARTIST:
                musicPlayerHandler.playArtistSongs(intent.getStringExtra("name"),
                        intent.getIntExtra("pos", 0));
                listType = ListType.ARTIST;
                updatePlayer();
                break;
            case ACTION_NOTI_CLICK:
                final Intent i = new Intent();
                if (MainActivity.activityRunning) {
                    i.setAction(PlayerFragment.ACTION_OPEN_PANEL);
                    sendBroadcast(i);
                } else {
                    i.setClass(context, MainActivity.class);
                    i.putExtra("openPanel", true);
                    i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                }
                break;
            case ACTION_NOTI_REMOVE:
                notificationHandler.setNotificationActive(false);
                musicPlayerHandler.getMediaPlayer().stop();
                break;
            case ACTION_ADD_QUEUE:
                musicPlayerHandler.addSongToQueue(intent.getLongExtra("songId", 0));
                break;
        }
    }
	
	
	private synchronized void restoreQueuesAndPositionIfNecessary() {
        if (!queuesRestored && playingQueue.isEmpty()) {
            ArrayList<Song> restoredQueue = MusicPlaybackQueueStore.getInstance(this).getSavedPlayingQueue();
            ArrayList<Song> restoredOriginalQueue = MusicPlaybackQueueStore.getInstance(this).getSavedOriginalPlayingQueue();
            int restoredPosition = PreferenceManager.getDefaultSharedPreferences(this).getInt(SAVED_POSITION, -1);
            int restoredPositionInTrack = PreferenceManager.getDefaultSharedPreferences(this).getInt(SAVED_POSITION_IN_TRACK, -1);

            if (restoredQueue.size() > 0 && restoredQueue.size() == restoredOriginalQueue.size() && restoredPosition != -1) {
				this.originalPlayingQueue = restoredOriginalQueue;
                this.playingQueue = restoredQueue;

                position = restoredPosition;
            //    openCurrent();
            //    prepareNext();

           //     if (restoredPositionInTrack > 0) seek(restoredPositionInTrack);

              //  notHandledMetaChangedForCurrentTrack = true;
              //  sendChangeInternal(META_CHANGED);
             //   sendChangeInternal(QUEUE_CHANGED);
            }
        }
        queuesRestored = true;
    }
	

    private void playAlbumSongs(final Intent intent) throws IOException {
        //For better performance
        musicPlayerHandler.playAlbumSongs(intent.getLongExtra("albumId", 0),
                intent.getIntExtra("songPos", 0));
        listType = ListType.ALBUM;
        updatePlayer();
    }

    private void playAllSongs(final Intent intent) throws IOException {
        //For better performance
        musicPlayerHandler.playAllSongs(intent.getLongExtra("songId", 0));
        listType = ListType.ALL;
        updatePlayer();
    }

    public void updatePlayer() {
        Intent i = new Intent();
        i.setAction(PlayerFragment.ACTION_RECIEVE_SONG);
        i.putExtra("running", musicPlayerHandler.getMediaPlayer().isPlaying());
        i.putExtra("songId", musicPlayerHandler.getCurrentPlayingSongId());
        i.putExtra("songName", musicPlayerHandler.getCurrentPlayingSong().getName());
        i.putExtra("albumId", musicPlayerHandler.getCurrentPlayingSong().getAlbumId());
        i.putExtra("albumName", musicPlayerHandler.getCurrentPlayingSong().getAlbumName());
        i.putExtra("seek", musicPlayerHandler.getMediaPlayer().getCurrentPosition());
        i.putExtra("pos", musicPlayerHandler.getCurrentPlayingPos());
        sendBroadcast(i);
        updateNotificationPlayer();
    }

    private void updateNotificationPlayer() {
        if (!notificationHandler.isNotificationActive())
            notificationHandler.setNotificationPlayer(false);
        notificationHandler.changeNotificationDetails(musicPlayerHandler
                .getCurrentPlayingSong().getName(), musicPlayerHandler
                .getCurrentPlayingSong().getArtist(), musicPlayerHandler
                .getCurrentPlayingSong().getAlbumId(), musicPlayerHandler
                .getMediaPlayer().isPlaying());
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        MediaPlayer mp = musicPlayerHandler.getMediaPlayer();
        if (mp != null) {
            mp.stop();
            mp.release();
        }
    }

    /*
    ListType is used to check if previously played list was same
    If same, then just switch to new Song. To avoid loading list of songs again and again
     */
    public enum ListType {
        ALL, ALBUM, ARTIST, SINGLE, PLAYLIST
    }
	
	
	private void saveQueuesImpl() {
        MusicPlaybackQueueStore.getInstance(this).saveQueues(playingQueue, originalPlayingQueue);
    }
	public void saveState() {
        saveQueues();
    //    savePosition();
   //     savePositionInTrack();
    }

	public ArrayList<Song> getPlayingQueue() {
        return playingQueue;
    }
	
	
    private void saveQueues() {
     //   queueSaveHandler.removeMessages(SAVE_QUEUES);
     //   queueSaveHandler.sendEmptyMessage(SAVE_QUEUES);
    }
	
}
