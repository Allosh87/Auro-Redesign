package com.allosh.xtraplayer.service;
import java.util.ArrayList;
import com.allosh.xtraplayer.utils.items.Song;
import android.database.Cursor;
import android.support.annotation.Nullable;
import android.support.annotation.NonNull;
import android.provider.MediaStore;

public class SongLoader
{


    @NonNull
    public static ArrayList<Song> getSongs(@Nullable final Cursor cursor) {
        ArrayList<Song> songs = new ArrayList<>();
        if (cursor != null && cursor.moveToFirst()) {
            do {
                songs.add(getSongFromCursorImpl(cursor));
            } while (cursor.moveToNext());
        }

        if (cursor != null)
            cursor.close();
        return songs;
    }


    @NonNull
    private static Song getSongFromCursorImpl(@NonNull Cursor musicCursor) {
		/*
        final int id = cursor.getInt(0);
        final String title = cursor.getString(1);
        final int trackNumber = cursor.getInt(2);
        final int year = cursor.getInt(3);
        final long duration = cursor.getLong(4);
        final String data = cursor.getString(5);
        final long dateModified = cursor.getLong(6);
        final int albumId = cursor.getInt(7);
        final String albumName = cursor.getString(8);
        final int artistId = cursor.getInt(9);
        final String artistName = cursor.getString(10);
*/
       // return new Song(id, title, artistName, albumId, albumName, artistId, artistName);
   
		int titleColumn = musicCursor.getColumnIndex
		(android.provider.MediaStore.Audio.Media.TITLE);
		int idColumn = musicCursor.getColumnIndex
		(android.provider.MediaStore.Audio.Media._ID);
		int artistColumn = musicCursor.getColumnIndex
		(android.provider.MediaStore.Audio.Media.ARTIST);
		int pathColumn = musicCursor.getColumnIndex
		(MediaStore.Audio.Media.DATA);
		int albumIdColumn = musicCursor.getColumnIndex
		(MediaStore.Audio.Media.ALBUM_ID);
		int albumColumn = musicCursor.getColumnIndex
		(MediaStore.Audio.Media.ALBUM);
		int addedDateColumn = musicCursor.getColumnIndex
		(MediaStore.Audio.Media.DATE_ADDED);
		int songDurationColumn = musicCursor.getColumnIndex
		(MediaStore.Audio.Media.DATE_ADDED);
	   
		return new Song(
		musicCursor.getLong(idColumn),
		musicCursor.getString(titleColumn),
		musicCursor.getString(artistColumn),
		musicCursor.getString(pathColumn), false,
		musicCursor.getLong(albumIdColumn),
		musicCursor.getString(albumColumn),
		musicCursor.getLong(addedDateColumn),
		musicCursor.getLong(songDurationColumn));
	}
	
}
